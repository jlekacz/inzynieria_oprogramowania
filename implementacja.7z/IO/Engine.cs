﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IO
{
    class Engine
    {
        public enum TypeTask { circuit, field }
        public enum TypeFigure { square, rectangle }
        private Figure figure;
        private UserInterface userInterface;
        DataBase dataBase;

        public Engine(UserInterface userInterface)
        {
            this.userInterface = userInterface;
            dataBase = new DataBase();
        }

        public void ShowHistory()
        {
            dataBase.LoadData();
        }

        public void Count(decimal a, decimal b, TypeTask typeTask, TypeFigure typeFigure)
        {
            if(typeFigure == TypeFigure.rectangle)
            {
                figure = new Rectangle(a, b);
                if(typeTask == TypeTask.field)
                {
                    userInterface.ShowResult(figure.Field.ToString());
                    dataBase.SaveData("Pole prostokąta o bokach " + a + " i " + b + " wynosi " + figure.Field.ToString());
                }
                else
                {
                    userInterface.ShowResult(figure.Circuit.ToString());
                    dataBase.SaveData("Obwód prostokąta o bokach " + a + " i " + b + " wynosi " + figure.Circuit.ToString());
                }
            }
            else
            {
                figure = new Square(a);
                if (typeTask == TypeTask.field)
                {
                    userInterface.ShowResult(figure.Field.ToString());
                    dataBase.SaveData("Pole kwadratu o boku " + a + " wynosi " + figure.Field.ToString());
                }
                else
                {
                    userInterface.ShowResult(figure.Circuit.ToString());
                    dataBase.SaveData("Obwód kwadratu o boku " + a + " wynosi " + figure.Circuit.ToString());
                }
            }
        }
    }
}
