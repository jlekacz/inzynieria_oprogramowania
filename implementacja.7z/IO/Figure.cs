﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IO
{
    abstract class Figure
    {
        protected decimal a;
        protected decimal b;
        public decimal Field { get; protected set; }
        public decimal Circuit { get; protected set; }

        public Figure(decimal a, decimal b)
        {
            this.a = a;
            this.b = b;
        }
    }
}
