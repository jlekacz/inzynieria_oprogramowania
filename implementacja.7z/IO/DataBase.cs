﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IO
{
    class DataBase
    {
        String path;

        public DataBase()
        {
            path = @"history.txt";
        }

        public void SaveData(string newData)
        {
            if (File.Exists(path) == false)
                File.Create(path).Dispose();
            TextReader fileToRead = new StreamReader(path);
            string fileContent = fileToRead.ReadToEnd();
            fileToRead.Close();
            TextWriter fileToWrite = new StreamWriter(path);
            fileToWrite.WriteLine(fileContent + newData);
            fileToWrite.Close();
        }

        public void LoadData()
        {
            TextReader fileToRead = new StreamReader(path);
            string fileContent = fileToRead.ReadToEnd();
            fileToRead.Close();
            MessageBox.Show(fileContent, "Historia");
        }
    }
}
