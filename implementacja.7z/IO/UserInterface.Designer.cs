﻿namespace IO
{
    partial class UserInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxA = new System.Windows.Forms.TextBox();
            this.labelA = new System.Windows.Forms.Label();
            this.labelB = new System.Windows.Forms.Label();
            this.textBoxB = new System.Windows.Forms.TextBox();
            this.comboBoxUnit = new System.Windows.Forms.ComboBox();
            this.buttonCount = new System.Windows.Forms.Button();
            this.labelResult = new System.Windows.Forms.Label();
            this.textBoxResult = new System.Windows.Forms.TextBox();
            this.radioButtonSquare = new System.Windows.Forms.RadioButton();
            this.radioButtonRectangle = new System.Windows.Forms.RadioButton();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.preferencjeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wyświetlHistorięToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.radioButtonCircuit = new System.Windows.Forms.RadioButton();
            this.radioButtonField = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBoxA
            // 
            this.textBoxA.Location = new System.Drawing.Point(12, 108);
            this.textBoxA.Name = "textBoxA";
            this.textBoxA.Size = new System.Drawing.Size(59, 20);
            this.textBoxA.TabIndex = 2;
            this.textBoxA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxAB_KeyPress);
            // 
            // labelA
            // 
            this.labelA.AutoSize = true;
            this.labelA.Location = new System.Drawing.Point(77, 111);
            this.labelA.Name = "labelA";
            this.labelA.Size = new System.Drawing.Size(35, 13);
            this.labelA.TabIndex = 3;
            this.labelA.Text = "bok A";
            // 
            // labelB
            // 
            this.labelB.AutoSize = true;
            this.labelB.Location = new System.Drawing.Point(199, 111);
            this.labelB.Name = "labelB";
            this.labelB.Size = new System.Drawing.Size(35, 13);
            this.labelB.TabIndex = 5;
            this.labelB.Text = "bok B";
            // 
            // textBoxB
            // 
            this.textBoxB.Location = new System.Drawing.Point(134, 108);
            this.textBoxB.Name = "textBoxB";
            this.textBoxB.Size = new System.Drawing.Size(59, 20);
            this.textBoxB.TabIndex = 4;
            this.textBoxB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxAB_KeyPress);
            // 
            // comboBoxUnit
            // 
            this.comboBoxUnit.FormattingEnabled = true;
            this.comboBoxUnit.Items.AddRange(new object[] {
            "",
            "km",
            "m",
            "cm",
            "mm"});
            this.comboBoxUnit.Location = new System.Drawing.Point(12, 135);
            this.comboBoxUnit.Name = "comboBoxUnit";
            this.comboBoxUnit.Size = new System.Drawing.Size(59, 21);
            this.comboBoxUnit.TabIndex = 6;
            // 
            // buttonCount
            // 
            this.buttonCount.Location = new System.Drawing.Point(12, 163);
            this.buttonCount.Name = "buttonCount";
            this.buttonCount.Size = new System.Drawing.Size(222, 43);
            this.buttonCount.TabIndex = 7;
            this.buttonCount.Text = "Licz";
            this.buttonCount.UseVisualStyleBackColor = true;
            this.buttonCount.Click += new System.EventHandler(this.buttonCount_Click);
            // 
            // labelResult
            // 
            this.labelResult.AutoSize = true;
            this.labelResult.Location = new System.Drawing.Point(11, 227);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(37, 13);
            this.labelResult.TabIndex = 8;
            this.labelResult.Text = "Wynik";
            // 
            // textBoxResult
            // 
            this.textBoxResult.Location = new System.Drawing.Point(56, 224);
            this.textBoxResult.Name = "textBoxResult";
            this.textBoxResult.Size = new System.Drawing.Size(59, 20);
            this.textBoxResult.TabIndex = 9;
            // 
            // radioButtonSquare
            // 
            this.radioButtonSquare.AutoSize = true;
            this.radioButtonSquare.Location = new System.Drawing.Point(6, 19);
            this.radioButtonSquare.Name = "radioButtonSquare";
            this.radioButtonSquare.Size = new System.Drawing.Size(64, 17);
            this.radioButtonSquare.TabIndex = 10;
            this.radioButtonSquare.TabStop = true;
            this.radioButtonSquare.Text = "Kwadrat";
            this.radioButtonSquare.UseVisualStyleBackColor = true;
            this.radioButtonSquare.CheckedChanged += new System.EventHandler(this.radioButtonSquare_CheckedChanged);
            // 
            // radioButtonRectangle
            // 
            this.radioButtonRectangle.AutoSize = true;
            this.radioButtonRectangle.Location = new System.Drawing.Point(6, 42);
            this.radioButtonRectangle.Name = "radioButtonRectangle";
            this.radioButtonRectangle.Size = new System.Drawing.Size(70, 17);
            this.radioButtonRectangle.TabIndex = 11;
            this.radioButtonRectangle.TabStop = true;
            this.radioButtonRectangle.Text = "Prostokąt";
            this.radioButtonRectangle.UseVisualStyleBackColor = true;
            this.radioButtonRectangle.CheckedChanged += new System.EventHandler(this.radioButtonRectangle_CheckedChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(247, 24);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.preferencjeToolStripMenuItem,
            this.wyświetlHistorięToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // preferencjeToolStripMenuItem
            // 
            this.preferencjeToolStripMenuItem.Name = "preferencjeToolStripMenuItem";
            this.preferencjeToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.preferencjeToolStripMenuItem.Text = "Preferencje";
            // 
            // wyświetlHistorięToolStripMenuItem
            // 
            this.wyświetlHistorięToolStripMenuItem.Name = "wyświetlHistorięToolStripMenuItem";
            this.wyświetlHistorięToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.wyświetlHistorięToolStripMenuItem.Text = "Wyświetl historię";
            this.wyświetlHistorięToolStripMenuItem.Click += new System.EventHandler(this.wyświetlHistorięToolStripMenuItem_Click);
            // 
            // radioButtonCircuit
            // 
            this.radioButtonCircuit.AutoSize = true;
            this.radioButtonCircuit.Location = new System.Drawing.Point(6, 42);
            this.radioButtonCircuit.Name = "radioButtonCircuit";
            this.radioButtonCircuit.Size = new System.Drawing.Size(59, 17);
            this.radioButtonCircuit.TabIndex = 14;
            this.radioButtonCircuit.TabStop = true;
            this.radioButtonCircuit.Text = "Obwód";
            this.radioButtonCircuit.UseVisualStyleBackColor = true;
            // 
            // radioButtonField
            // 
            this.radioButtonField.AutoSize = true;
            this.radioButtonField.Location = new System.Drawing.Point(6, 19);
            this.radioButtonField.Name = "radioButtonField";
            this.radioButtonField.Size = new System.Drawing.Size(46, 17);
            this.radioButtonField.TabIndex = 13;
            this.radioButtonField.TabStop = true;
            this.radioButtonField.Text = "Pole";
            this.radioButtonField.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonSquare);
            this.groupBox1.Controls.Add(this.radioButtonRectangle);
            this.groupBox1.Location = new System.Drawing.Point(14, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(87, 72);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButtonField);
            this.groupBox2.Controls.Add(this.radioButtonCircuit);
            this.groupBox2.Location = new System.Drawing.Point(119, 30);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(85, 72);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            // 
            // UserInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(247, 262);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBoxResult);
            this.Controls.Add(this.labelResult);
            this.Controls.Add(this.buttonCount);
            this.Controls.Add(this.comboBoxUnit);
            this.Controls.Add(this.labelB);
            this.Controls.Add(this.textBoxB);
            this.Controls.Add(this.labelA);
            this.Controls.Add(this.textBoxA);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "UserInterface";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxA;
        private System.Windows.Forms.Label labelA;
        private System.Windows.Forms.Label labelB;
        private System.Windows.Forms.TextBox textBoxB;
        private System.Windows.Forms.ComboBox comboBoxUnit;
        private System.Windows.Forms.Button buttonCount;
        private System.Windows.Forms.Label labelResult;
        private System.Windows.Forms.TextBox textBoxResult;
        private System.Windows.Forms.RadioButton radioButtonSquare;
        private System.Windows.Forms.RadioButton radioButtonRectangle;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem preferencjeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wyświetlHistorięToolStripMenuItem;
        private System.Windows.Forms.RadioButton radioButtonCircuit;
        private System.Windows.Forms.RadioButton radioButtonField;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;

    }
}

