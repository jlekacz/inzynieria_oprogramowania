﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IO
{
    public partial class UserInterface : Form
    {
        private decimal a;
        private decimal b;
        private Engine.TypeTask task;
        private Engine.TypeFigure figure;
        private Engine engine;

        public UserInterface()
        {
            InitializeComponent();
            engine = new Engine(this);
        }

        public void ShowResult(String result)
        {
            String unit=null;
            if (comboBoxUnit.Text != "")
            {
                unit = comboBoxUnit.Text;
                if(task == Engine.TypeTask.field)
                    unit +="^2";
            }
            textBoxResult.Text = result+unit;
        }

        private void radioButtonSquare_CheckedChanged(object sender, EventArgs e)
        {
            textBoxB.Enabled = false;
        }

        private void radioButtonRectangle_CheckedChanged(object sender, EventArgs e)
        {
            textBoxB.Enabled = true;
        }

        private void buttonCount_Click(object sender, EventArgs e)
        {
            if (radioButtonCircuit.Checked == true)
                task = Engine.TypeTask.circuit;
            else if (radioButtonField.Checked == true)
                task = Engine.TypeTask.field;
            else
            {
                MessageBox.Show( "Nie zaznaczono typu obliczeń", "Błąd");
                return;
            }

            if (radioButtonSquare.Checked == true)
                figure = Engine.TypeFigure.square;
            else if (radioButtonRectangle.Checked == true)
                figure = Engine.TypeFigure.rectangle;
            else
            {
                MessageBox.Show("Nie zaznaczono figury", "Błąd");
                return;
            }

            try
            {
                a = Decimal.Parse(textBoxA.Text);
                if(figure == Engine.TypeFigure.rectangle)
                    b = Decimal.Parse(textBoxB.Text);
            }
            catch
            {
                MessageBox.Show("Wprowadź poprawne liczby", "Błąd");
                return;
            }

            engine.Count(a, b, task, figure);
            
        }

        private void textBoxAB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '.')
                e.KeyChar = ',';
        }

        private void wyświetlHistorięToolStripMenuItem_Click(object sender, EventArgs e)
        {
            engine.ShowHistory();
        }      
    }
}
