﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IO
{
    class Rectangle : Figure
    {
        public Rectangle(decimal a, decimal b)
            : base(a, b)
        {
            Field = a * b;
            Circuit = 2 * a + 2 * b;
        }
    }
}
