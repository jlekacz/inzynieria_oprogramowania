﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IO
{
    class Square : Figure
    {
        public Square(decimal a)
            : base(a, a)
        {
            Field = a * a;
            Circuit = 4 * a;
        }
    }
}
